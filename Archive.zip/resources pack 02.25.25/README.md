# Slightly Improved Font

This is a simple resource pack that only adds upscaled version of Minecraft font.

![](https://user-images.githubusercontent.com/3844385/152986115-17ea0c57-bcdf-4bdf-947a-8665b3518b66.png)

To use it, download this project as zip, add it to your Minecraft instance Resource Packs folder (Click Open Pack Folder from settings to find it) and move the HD Font pack to Selected

![](https://user-images.githubusercontent.com/3844385/152986343-1e121622-d304-40c6-b158-b04af45883fb.png)
